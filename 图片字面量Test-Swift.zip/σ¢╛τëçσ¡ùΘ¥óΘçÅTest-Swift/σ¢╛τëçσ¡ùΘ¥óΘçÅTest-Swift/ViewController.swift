//
//  ViewController.swift
//  图片字面量Test-Swift
//
//  Created by ma c on 16/4/19.
//  Copyright © 2016年 lu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let imageView = UIImageView(frame: CGRect(x: 0.0, y: 0.0, width: 100, height: 100))
//        imageView.image = [#Image(imageLiteral: "header.png")#]
        imageView.image = UIImage(named: "header")
        imageView.contentMode = .ScaleAspectFill
        self.view.addSubview(imageView)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

