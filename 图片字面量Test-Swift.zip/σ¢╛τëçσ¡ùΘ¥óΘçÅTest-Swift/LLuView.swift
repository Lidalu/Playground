//
//  LLuView.swift
//  图片字面量Test-Swift
//
//  Created by ma c on 16/4/19.
//  Copyright © 2016年 lu. All rights reserved.
//

import UIKit
import Foundation

public class LLuView: UIView {

    override public init(frame: CGRect) {
        
        super.init(frame: frame)
        let label = UILabel(frame: CGRect(x: 100, y: 100, width: 100, height: 30))
        label.text = "This is a test label"
        label.textColor = UIColor.redColor()
        label.font = UIFont.systemFontOfSize(30)
        
        self.addSubview(label)
        
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
